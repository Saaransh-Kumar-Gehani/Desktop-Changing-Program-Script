# Importing required modules
import keyboard
import requests
import ctypes
import os


# Variables
IMG = []
c = -1
ButtonToShiftNext = "up"
ButtonToShiftPrevious = "down"
ButtonToSave = "space"
ButtonToExit = "esc"
# Set Image Folder you are going to use
cwd = os.getcwd()
ImageFolder = f"{cwd}\\Images"
SaveLoco = f"{cwd}"
if os.path.exists(ImageFolder):
    pass
else:
    os.mkdir("Images")


# Function to Add Image into the IMG list
def AddIMG(c):
    url = 'https://picsum.photos/1920/1080'
    r = requests.get(url)
    open(f'{ImageFolder}\\img-{c}.jpg','wb').write(r.content)
    img = f"{ImageFolder}\\img-{c}.jpg"
    IMG.append(img)


# Function that sets your wallpaper to given Image using IMG list index
def SetIMG(n):
    ctypes.windll.user32.SystemParametersInfoW(20, 0, IMG[n], 0)    


# Main Function that does most stuff.
def Main(st):
    global c
    if st == 'Next':
        if c+1 == len(IMG):
            c+=1
            AddIMG(c)
            SetIMG(c)
        elif 0 < c+1 < len(IMG):
            c+=1
            SetIMG(c)
    elif st == 'Back':
        if c-1 != -1:
            c-=1
            SetIMG(c)


# Function to save Image
s = 1
def Save(): 
    global s
    with open(f'{ImageFolder}\\img-{c}.jpg','rb') as file:
        content = file.read()
        open(f'{SaveLoco}\\SavedImage{s}.jpg','wb').write(content)
        s+=1
 
 
# You can set your key to change the Image
keyboard.add_hotkey(ButtonToShiftNext, Main, args=['Next'])
keyboard.add_hotkey(ButtonToShiftPrevious, Main, args=['Back'])

# Key save your favorite Image
keyboard.add_hotkey(ButtonToSave, Save)

# Key to break the program
keyboard.wait(ButtonToExit)


# This part of the code just deletes all the Images so that you don't occupy space
for i in IMG:
    os.remove(i)





